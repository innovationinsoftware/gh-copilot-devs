// server.js (CommonJS MCP server)
const { Server } = require("@modelcontextprotocol/sdk/server/index.js");
const { StdioServerTransport } = require("@modelcontextprotocol/sdk/server/stdio.js");

// Create the MCP server
const server = new Server(
  { name: "hello", version: "1.0.0" },
  { capabilities: { tools: {} } }
);

// Define the "ping" tool
server.tool(
  "ping",
  {
    description: "Replies with 'pong'.",
    inputSchema: { type: "object", properties: {} }
  },
  async () => {
    console.error("[hello] ping called");
    return { content: [{ type: "text", text: "pong" }] };
  }
);

// Start the server over stdio
server.connect(new StdioServerTransport()).then(() => {
  console.error("hello MCP (stdio) server is running");
});